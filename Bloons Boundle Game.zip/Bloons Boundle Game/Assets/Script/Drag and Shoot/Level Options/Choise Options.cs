using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChoiseOptions : MonoBehaviour
{
    public Button[] Options_Game;
    public GameObject[] GameLevels;
    public GameObject[] LevelsScript;
    public GameObject OptionPanel;
    private int optionIs;
    int n;
    private void Awake()
    {
        Options_Game[0].enabled = false;
        Options_Game[1].enabled = true;
        Options_Game[2].enabled = true;
    }

    public void Options()
    {
         n = FindObjectOfType<LevelLoading>().buttonIndex;
        switch (n)
        {
            case 1:

                Options_Game[0].enabled = false;
                Options_Game[1].enabled = true;
                Options_Game[2].enabled = true;
                FindObjectOfType<LevelsStorage>().DestroyObjectsAndDisableScripts(1);
                FindObjectOfType<LevelsStorage>().DestroyObjectsAndDisableScripts(2);
                optionIs = n;
                StartCoroutine(LoadingGotoGameOptions(optionIs));
                break;
            case 2:

                Options_Game[0].enabled = true;
                Options_Game[1].enabled = false;
                Options_Game[2].enabled = true;
                FindObjectOfType<LevelsStorage>().DestroyObjectsAndDisableScripts(0);
                FindObjectOfType<LevelsStorage>().DestroyObjectsAndDisableScripts(2);
                optionIs = n;
                StartCoroutine(LoadingGotoGameOptions(optionIs));
                break;
            case 3:

                Options_Game[0].enabled = true;
                Options_Game[1].enabled = true;
                Options_Game[2].enabled = false;
                FindObjectOfType<LevelsStorage>().DestroyObjectsAndDisableScripts(1);
                FindObjectOfType<LevelsStorage>().DestroyObjectsAndDisableScripts(0);
                optionIs = n;
                StartCoroutine(LoadingGotoGameOptions(optionIs));
                break;
        }
    }

    IEnumerator LoadingGotoGameOptions(int optionIs)
    {
        yield return new WaitForSeconds(0.5f);

        if (optionIs.Equals(1))
        {
            FindObjectOfType<InstantiateObjects>().count = 0;
            GameLevels[optionIs - 1].SetActive(true);
            LevelsScript[optionIs - 1].SetActive(true);

            DisableOtherLevels(1, 2);
            OptionPanel.SetActive(false);

            n = 0;
        }
        else if (optionIs.Equals(2))
        {
            FindObjectOfType<InstantiateObjects>().count = 0;
            GameLevels[optionIs - 1].SetActive(true);
            LevelsScript[optionIs - 1].SetActive(true);

            DisableOtherLevels(0, 2);
            OptionPanel.SetActive(false);
            n = 0;
        }
        else if (optionIs.Equals(3))
        {
            FindObjectOfType<InstantiateObjects>().count = 0;
            GameLevels[optionIs - 1].SetActive(true);
            LevelsScript[optionIs - 1].SetActive(true);

            DisableOtherLevels(0, 1);
            OptionPanel.SetActive(false);

            n = 0;
        }
    }

    private void DisableOtherLevels(int level_disable1, int level_disable2)
    {
        GameLevels[level_disable1].SetActive(false);
        GameLevels[level_disable2].SetActive(false);        
        
        LevelsScript[level_disable1].SetActive(false);
        LevelsScript[level_disable2].SetActive(false);
    }
}
