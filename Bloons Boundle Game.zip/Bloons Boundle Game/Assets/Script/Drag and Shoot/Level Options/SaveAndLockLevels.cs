using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveAndLockLevels : MonoBehaviour
{
    public int[] levels;
}
