using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelLoading: MonoBehaviour
{
    float speed = 1000;

    [Header("Components")]
    [SerializeField] private float loadings;
    private bool isPlay;
    public int buttonIndex = 0, index;
    public bool gameUpdate;
    [Header("Transform")]
    [SerializeField] private Transform loadingLogo;
    [SerializeField] private GameObject loading;

    private void Update()
    {
            FindObjectOfType<ControllLevel>().CheckCompletedLevels();
        
        Loading();
    }

    public void SetUpGame()
    {
        buttonIndex = 0;
        for (int i = 0; i < 3; i++)
        {
            FindObjectOfType<ChoiseOptions>().Options_Game[i].enabled = true;
            FindObjectOfType<ChoiseOptions>().GameLevels[i].SetActive(false);
            FindObjectOfType<ChoiseOptions>().LevelsScript[i].SetActive(false); 

        }  
    }

    public void PlayGame(int n)
    {
        int level = n;
        
        for (int i = 0; i < FindObjectOfType<SaveAndLockLevels>().levels.Length; i++)
        {
            if (level.Equals(FindObjectOfType<SaveAndLockLevels>().levels[i]))
            {
                //levelAudio.Play();
                StartCoroutine(wait());
                IEnumerator wait()
                {
                    loading.SetActive(true);
                    yield return new WaitForSeconds(1f);
                    index = n;
                    isPlay = true;
                    gameUpdate = true;
                    level = 0;
                }
               // break;
            }
        }  
    }

    void Loading()
    {
        if (isPlay)
        {
            loadingLogo.Rotate(0f, 0f, speed * Time.deltaTime);
            speed = (speed - loadings);
            if (speed<=0)
            {
                loading.SetActive(false);
                buttonIndex = index;
                isPlay = false;
                FindObjectOfType<ChoiseOptions>().Options();
            }
        }
    }

}
