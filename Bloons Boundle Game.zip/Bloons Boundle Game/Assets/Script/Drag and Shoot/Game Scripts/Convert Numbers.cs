using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ConvertNumbers : MonoBehaviour
{
    public void convert(int value, Text text)
    {
        var convert = string.Format("{0:#,#0.0}", value);
        text.text = convert.ToString();
    }
}
