using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundDetect : MonoBehaviour
{
    [SerializeField] ParticleSystem _particleSystem, _boom;
    [HideInInspector] public float health = 0f;
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("bullons"))
        {
            FindObjectOfType<InstantiateObjects>().count--;
            // health+=0.3f;
            //  FindObjectOfType<Health>().controllerPlayerHealth(health);
            var particle = Instantiate(_particleSystem, collision.transform.position, Quaternion.identity);
            particle.Play();
            Destroy(collision.gameObject);
        }else if (collision.gameObject.CompareTag("ball"))
        {
           // FindObjectOfType<Audios>().playSfx(0);
        }else if (collision.gameObject.CompareTag("boom"))
        {
            var boom = Instantiate(_boom, collision.transform.position, Quaternion.identity);
            boom.Play();
            Destroy(collision.gameObject);
        }
    }
}
