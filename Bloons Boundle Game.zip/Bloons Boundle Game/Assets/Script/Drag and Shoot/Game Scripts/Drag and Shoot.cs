using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(LineRenderer))]

public class DragandShoot : MonoBehaviour
{
    public LineRenderer lineRenderer;
    bool isDragging;
    public Rigidbody2D ballRigibody2d;
    public float dragSped = 3f;
    public float forceToAdd = 10f;
    [Header("Main Camera")]
    private Camera camera;
    

    Vector3 mousePositions
    {
        get 
        { 
            Vector3 position = camera.ScreenToWorldPoint(Input.mousePosition);
            position.z = 0f;
            return position; 
        }
    }
    void Start()
    {
        camera = Camera.main;
        lineRenderer.enabled = false;
        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0,Vector2.zero);
        lineRenderer.SetPosition(1,Vector2.zero);
    }

    void Update()
    {
        if(Input.GetMouseButtonDown(0) && !isDragging)
        {
            FindObjectOfType<Audios>().playSfx(3);
            DragePointStart();
        }
        if(isDragging)
        {
            Draging();
        }
        if(Input.GetMouseButtonUp(0) && isDragging)
        {
            EndOfDrage();
        }
    }


    // script controll
    void EndOfDrage()
    {
        isDragging = false;
        lineRenderer.enabled = false;

        Vector3 startPosition = lineRenderer.GetPosition(0);
        Vector3 currentPosition = lineRenderer.GetPosition(1);

        Vector3 distance = currentPosition - startPosition;
        Vector3 finalForce = distance * forceToAdd;

        ballRigibody2d.AddForce(- finalForce, ForceMode2D.Impulse);

    }


    void Draging()
    {
        Vector3 startPosition = lineRenderer.GetPosition(0);
        Vector3 currentPosition = mousePositions;

        Vector3 distanceBall = currentPosition - startPosition;
        if (distanceBall.magnitude <= dragSped)
        {
            lineRenderer.SetPosition(1, currentPosition);
        }
        else
        {
            Vector3 limit = startPosition + (distanceBall.normalized * dragSped);
            lineRenderer.SetPosition(1, limit);
        }
    }


    void DragePointStart()
    {
        isDragging = true;
      //  lineRenderer.enabled = true;
        lineRenderer.SetPosition(0, mousePositions);
        Vector3 currentPosition = mousePositions;
        lineRenderer.SetPosition(1, currentPosition);
    }
}
