using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gravity : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
       // Physics2D.gravity = new Vector2(0, -25);
    }

    public void gravityScaleBalloons(float gravityValue)
    {
        for(int i = 0; i < FindObjectOfType<InstantiateObjects>().grid.transform.childCount; i++)
            FindObjectOfType<InstantiateObjects>().grid.transform.GetChild(i).GetComponent<Rigidbody2D>().gravityScale = gravityValue;
    }

    public void gravityScaleBalloons(float gravityValue, bool isSimulated)
    {
        for (int i = 0; i < FindObjectOfType<InstantiateObjects>().grid.transform.childCount; i++)
        {
            FindObjectOfType<InstantiateObjects>().grid.transform.GetChild(i).GetComponent<Rigidbody2D>().simulated = isSimulated;
            FindObjectOfType<InstantiateObjects>().grid.transform.GetChild(i).GetComponent<Rigidbody2D>().gravityScale = gravityValue;
        }

    }

}
