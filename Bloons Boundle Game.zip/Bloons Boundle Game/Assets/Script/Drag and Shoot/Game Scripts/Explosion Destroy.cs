using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosionDestroy : MonoBehaviour
{
    private void Start()
    {
        StartCoroutine(destroyObject());
    }
    IEnumerator destroyObject()
    {
        yield return new WaitForSeconds(0.3f);
        Destroy(gameObject);
    }
}
