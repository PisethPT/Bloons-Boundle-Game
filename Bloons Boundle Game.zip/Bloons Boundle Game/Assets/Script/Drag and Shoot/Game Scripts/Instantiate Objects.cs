using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class InstantiateObjects : MonoBehaviour
{
    public GameObject[] bullons;
    public GameObject grid;
    public Vector3 localeScale;
    public Canvas canvas;
    [HideInInspector] public int scores = 0;
    public Text scoreText;
    int posX, posY;
    [HideInInspector] public int count = 0;

    private void Awake()
    {
        scores = PlayerPrefs.GetInt("Scores");
        scoreText.text = scores.ToString();

            FindObjectOfType<SaveAndLockLevels>().levels[0] = PlayerPrefs.GetInt("Level1");
            FindObjectOfType<SaveAndLockLevels>().levels[1] = PlayerPrefs.GetInt("Level2");
            FindObjectOfType<SaveAndLockLevels>().levels[2] = PlayerPrefs.GetInt("Level3");
            
    }

    private void InstantiateBlocks()
    {
        int r = Random.Range(0,bullons.Length);
        posX = Random.Range(-200, 250);
        posY = Random.Range(20, -200);

        var clon = Instantiate(bullons[r], new Vector2(posX, posY), Quaternion.identity);
        clon.transform.position = new Vector3(clon.transform.position.x, clon.transform.position.y, -1f);
        clon.transform.SetParent(grid.transform, false);
        clon.name = posX + "_" + posY;
        clon.transform.localScale = localeScale;
        count++;
    }

    private void Update()
    {
        if (count <=20)
        {
            InstantiateBlocks();
        }
    }

    bool isActive = true;
    public void StopGame()
    {
        isActive = !isActive;
        if(isActive)
        {
            Time.timeScale = 0f;
        }        if(!isActive)
        {
            Time.timeScale = 1f;
        }
        
    }
}
