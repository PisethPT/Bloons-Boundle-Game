using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class Collider : MonoBehaviour
{
    [SerializeField] ParticleSystem _particleSystem, _boom;
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("bullons"))
        {
            FindObjectOfType<Audios>().playSfx(1);
            var particle = Instantiate(_particleSystem,collision.transform.position,Quaternion.identity);
            particle.Play();
            Destroy(collision.gameObject);
            FindObjectOfType<InstantiateObjects>().count--;
            FindObjectOfType<InstantiateObjects>().scores++;
            convert(FindObjectOfType<InstantiateObjects>().scores, FindObjectOfType<InstantiateObjects>().scoreText);
        }else if (collision.gameObject.CompareTag("boom"))
        {
            FindObjectOfType<Audios>().playSfx(2);
            var boom = Instantiate(_boom, collision.transform.position, Quaternion.identity);
            boom.Play();
            FindObjectOfType<GroundDetect>().health += 0.3f;
            FindObjectOfType<Health>().controllerPlayerHealth(FindObjectOfType<GroundDetect>().health);
            Destroy(collision.gameObject);
        }
        

    }
    public void convert(int value, Text text)
    {
        var convert = string.Format("{0:#,#0.0}", value);
        text.text = convert.ToString();
    }
}
