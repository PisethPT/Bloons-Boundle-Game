using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CallingHome : MonoBehaviour
{
    public void HomeButton()
    {
        FindObjectOfType<SaveGameScores>().saveScores();
        gameObject.SetActive(true);
        FindObjectOfType<gravity>().gravityScaleBalloons(0f, false);
        FindObjectOfType<Health>().OptionButton.enabled = false;
        FindObjectOfType<Health>().buttonLevel.enabled = false;
    }
    public void  OkeyConfirm()
    {
        StartCoroutine(OkeyConfirms());
    }
    IEnumerator OkeyConfirms()
    {
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene(0);
    }
    public void Cancel()
    {
        FindObjectOfType<gravity>().gravityScaleBalloons(0.005f, true);
        FindObjectOfType<Health>().OptionButton.enabled = true;
        FindObjectOfType<Health>().buttonLevel.enabled = true;
        gameObject.SetActive(false);
    }
}
