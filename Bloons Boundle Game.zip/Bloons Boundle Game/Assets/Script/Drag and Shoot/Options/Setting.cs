using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Setting : MonoBehaviour
{
    [SerializeField] private GameObject SettingPanel;
    [SerializeField] private GameObject LevelPanel;
    private bool oPress = true;

    public void Options()
    {
        oPress = !oPress;
        if (oPress)
        {
            // Time.timeScale = 1f;
            FindObjectOfType<gravity>().gravityScaleBalloons(0.005f,true);
            FindObjectOfType<Health>().buttonLevel.enabled = true;
            SettingPanel.SetActive(false);
        }else if(!oPress)
        {
            // Time.timeScale = 0f;
            FindObjectOfType<Health>().buttonLevel.enabled = false;
            FindObjectOfType<Health>().homeButton.enabled = false;
            FindObjectOfType<gravity>().gravityScaleBalloons(-0.005f, false);
            SettingPanel.SetActive(true);
        }
    }

    public void resume() 
    {
        FindObjectOfType<Health>().buttonLevel.enabled = true;
        FindObjectOfType<Health>().homeButton.enabled = true;
        FindObjectOfType<gravity>().gravityScaleBalloons(0.005f, true);
        SettingPanel.SetActive(false);
        FindObjectOfType<Health>().losePanel.SetActive(false);
        FindObjectOfType<ControllLevel>().congratulationPanel.SetActive(false);
        oPress = true;
        Time.timeScale = 1f;
    }
    public void replay() 
    {
        FindObjectOfType<SaveGameScores>().saveScores();
        FindObjectOfType<Health>().buttonLevel.enabled = true;
        FindObjectOfType<Health>().homeButton.enabled = true;
        FindObjectOfType<Health>().losePanel.SetActive(false);
        Time.timeScale = 1f;
        SceneManager.LoadScene(1);
    }

    public void exitLoad()
    {
        FindObjectOfType<SaveGameScores>().saveScores();
        SceneManager.LoadScene(0);
    }

    public void showLevelPanel()
    {
        FindObjectOfType<ControllLevel>().congratulationPanel.SetActive(false) ;
        FindObjectOfType<SaveGameScores>().saveScores();
        FindObjectOfType<Health>().OptionButton.enabled = false;
        FindObjectOfType<Health>().homeButton.enabled = false;
        FindObjectOfType<gravity>().gravityScaleBalloons(0, false);
        LevelPanel.SetActive(true);
    }

    public void closeLevel()
    {
        FindObjectOfType<Health>().OptionButton.enabled = true;
        FindObjectOfType<Health>().homeButton.enabled = true;
        FindObjectOfType<gravity>().gravityScaleBalloons(0.005f, true);
        LevelPanel.SetActive(false);
    }

}
