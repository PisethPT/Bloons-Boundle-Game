using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Health : MonoBehaviour
{
    public GameObject losePanel;
    public Button buttonLevel, OptionButton, homeButton;
    public Text healthText, scoreText;
    public void controllerPlayerHealth(float health)
    {
        gameObject.transform.GetChild(0).GetComponent<Image>().fillAmount -= health;
        if (gameObject.transform.GetChild(0).GetComponent<Image>().fillAmount <= 0)
        {
            FindObjectOfType<SaveGameScores>().saveScores();
            FindAnyObjectByType<DragandShoot>().dragSped = 0f;
            FindObjectOfType<Collider>().convert(FindObjectOfType<InstantiateObjects>().scores, scoreText);
            losePanel.SetActive(true);
            buttonLevel.enabled = false;
            OptionButton.enabled = false;
            homeButton.enabled = false;
            FindObjectOfType<gravity>().gravityScaleBalloons(0f, false);
        }
    }
}
