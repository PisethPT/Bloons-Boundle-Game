using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class About : MonoBehaviour
{


    public void startGame()
    {
       FindObjectOfType<HomeController>().loadingObj.SetActive(true);
        FindObjectOfType<HomeController>().isPlay = true;
        
    }

    public void closeAboutPanel()
    {
        SceneManager.LoadScene(1);
        Time.timeScale = 1.0f;
        FindObjectOfType<gravity>().gravityScaleBalloons(0.005f, true);
        gameObject.SetActive(false);
        Destroy(gameObject);
        
    }

}
