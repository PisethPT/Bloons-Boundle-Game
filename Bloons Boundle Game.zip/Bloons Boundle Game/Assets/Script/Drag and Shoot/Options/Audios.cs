using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Audios : MonoBehaviour
{
    [SerializeField] protected AudioSource[] musicPlay;
    [SerializeField] protected AudioSource[] sfxPlay;
    public Text music_onOff;
    public Text sfx_onOff;
    private bool mPaused = true;
    private bool sfxPaused = true;
    private int musicIndex;

    public void playMusic(int musicIndex)
    {
        this.musicIndex = musicIndex;
        musicPlay[musicIndex].Play();
    }
    public void toggleMusic()
    {
        mPaused = !mPaused;
        if(mPaused)
        {
            musicPlay[musicIndex].Play();
            musicPlay[musicIndex].mute = false;
            music_onOff.text = "On";
        }
        if(!mPaused)
        {
            musicPlay[0].Play();
            musicPlay[0].mute = true;
            music_onOff.text = "Off";
        }
    }    
    
    public void playSfx(int sfxIndexs)
    {
        sfxPlay[sfxIndexs].Play();
    }

    public void toggleSfx()
    {
        sfxPaused = !sfxPaused;
        if(sfxPaused)
        {
            sfxPlay[0].Play();
            sfxPlay[0].mute = false;            
            sfxPlay[1].Play();
            sfxPlay[1].mute = false;            
            sfxPlay[2].Play();
            sfxPlay[2].mute = false;
            sfx_onOff.text = "On";
        }
        if(!sfxPaused)
        {
            sfxPlay[0].Play();
            sfxPlay[0].mute = true;            
            sfxPlay[1].Play();
            sfxPlay[1].mute = true;            
            sfxPlay[2].Play();
            sfxPlay[2].mute = true;
            sfx_onOff.text = "Off";
        }
    }
}
