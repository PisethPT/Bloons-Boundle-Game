using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeController : MonoBehaviour
{
    public ParticleSystem balloons;
    public Sprite[] sprites;
    float time = 2f;
    public Transform loading;
    public GameObject loadingObj;
    public bool isPlay;
    float speed = 1000f;
    public GameObject panel, home;
    void Update()
    {
        time -= Time.deltaTime;
        if (time <= 0)
        {
            StartCoroutine(wait());
        }

        Loading();
    }

   
    void Loading()
    {
        if (isPlay)
        {
            loading.Rotate(0f, 0f, speed * Time.deltaTime);
            speed = (speed - 10);
            if (speed <= 0)
            {
                panel.SetActive(true);
                home.SetActive(false);
                loadingObj.SetActive(false);
                isPlay = false;
                StartCoroutine(show());
            }
        }
    }
    IEnumerator show()
    {
        yield return new WaitForSeconds(1f);
        Time.timeScale = 0f;
    }
    IEnumerator wait()
    {
        int r = Random.Range(0, sprites.Length);
        balloons.textureSheetAnimation.SetSprite(0,sprites[r]);
        balloons.Play();
        yield return new WaitForSeconds(0.1f);
        time = 2f;
    }

    public void exitGame()
    {
        Application.Quit();
    }
}
