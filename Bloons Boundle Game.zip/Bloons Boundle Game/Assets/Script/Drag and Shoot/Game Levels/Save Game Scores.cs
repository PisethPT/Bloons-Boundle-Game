using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveGameScores : MonoBehaviour
{
    [Header("Player Scores")]
    public int playerScore = 0;
    public int level1,level2, level3;

    public void saveScores()
    {

            PlayerPrefs.SetInt("Level1", level2 = FindObjectOfType<SaveAndLockLevels>().levels[0]);
            PlayerPrefs.SetInt("Level2", level2 = FindObjectOfType<SaveAndLockLevels>().levels[1]);
            PlayerPrefs.SetInt("Level3", level3 = FindObjectOfType<SaveAndLockLevels>().levels[2]);

            Debug.Log("Level1: " + PlayerPrefs.GetInt("Level1"));
            Debug.Log("Level2: " + PlayerPrefs.GetInt("Level2"));
            Debug.Log("Level3: " + PlayerPrefs.GetInt("Level3"));
        

        playerScore = FindObjectOfType<InstantiateObjects>().scores;
        PlayerPrefs.SetInt("Scores", playerScore);

        Debug.Log("Scores: " + PlayerPrefs.GetInt("Scores"));
    }
}
