using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelsStorage : MonoBehaviour
{
    public GameObject[] gridPolygons;
    public GameObject[] balloonPlayers;
    public void DestroyObjectsAndDisableScripts(int level_disable)
    {
        for(int i = 0; i < gridPolygons.Length; i++)
        {
            if (i.Equals(level_disable))
            {
                for (int j = 0; j < gridPolygons[level_disable].transform.childCount; j++)
                {
                    Destroy(gridPolygons[level_disable].transform.GetChild(j).gameObject);
                }
              //  balloonPlayers[level_disable].SetActive(false);
            }
        }
    }
}
