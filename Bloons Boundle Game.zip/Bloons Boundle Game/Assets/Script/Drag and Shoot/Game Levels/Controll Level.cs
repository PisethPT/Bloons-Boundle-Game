using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class ControllLevel : MonoBehaviour
{
    public GameObject congratulationPanel;
    public Text scoreText, healthText;
    public bool isCheck1 = true, isCheck2 = true;
    float health= 0;

    public void UpadetLevels()
    {
        if (FindObjectOfType<InstantiateObjects>().scores.Equals(20)  && FindObjectOfType<SaveAndLockLevels>().levels[1].Equals(2))
        {

        }else if(FindObjectOfType<InstantiateObjects>().scores.Equals(5000) && FindObjectOfType<SaveAndLockLevels>().levels[2].Equals(3))
        {

        }
        else if(FindObjectOfType<InstantiateObjects>().scores < 1000 && FindObjectOfType<SaveAndLockLevels>().levels[0].Equals(1))
        {

        }
    }

    public void CheckCompletedLevels()
    {
        if (FindObjectOfType<InstantiateObjects>().scores.Equals(1000) && isCheck1) // scores for level 2
        {
            CongratulationPanel(1, 2);
            isCheck1 = false;
        }        
        
        if (FindObjectOfType<InstantiateObjects>().scores.Equals(5000) && isCheck2) // scores for level 3
        {
            CongratulationPanel(2, 3);
            isCheck2 = false;
        }       
       
    }


    private void CongratulationPanel(int level, int value)
    {
        print("player scores: " + FindObjectOfType<InstantiateObjects>().scores);
        FindObjectOfType<GroundDetect>().health = 0f;
        health = FindObjectOfType<Health>().gameObject.transform.GetChild(0).GetComponent<Image>().fillAmount = 1;
        FindObjectOfType<Collider>().convert(FindObjectOfType<InstantiateObjects>().scores, scoreText);
        FindObjectOfType<Collider>().convert(3, healthText);
        FindObjectOfType<gravity>().gravityScaleBalloons(0f, false);
        congratulationPanel.SetActive(true);
        FindObjectOfType<SaveAndLockLevels>().levels[level] = value;
        FindObjectOfType<SaveGameScores>().saveScores();
    }

 
}
