using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]
[RequireComponent (typeof(LineRenderer))]
public class CheckMatch : MonoBehaviour
{
    private LineRenderer lineRenderer;
    [SerializeField] private int objectIDKey;
    private bool isAction;
    private Vector3 endOfPoin;
    private ObjectID checkMatch;
    [SerializeField] private int coutWin = 0;



    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.GetComponent<LineRenderer>().useWorldSpace = false;
        lineRenderer.positionCount = 2;
    }
    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            lineRenderer.GetComponent<LineRenderer>().useWorldSpace = true;
            RaycastHit2D raycastHit2D = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(Input.mousePosition), Vector2.zero);
            if(raycastHit2D.collider != null && raycastHit2D.collider.gameObject == gameObject) 
            {
                isAction = true;
                Vector3 mousePositon = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                mousePositon.z = 0f;
                lineRenderer.SetPosition(0,mousePositon);
            }
        }
        if(isAction)
        {
            Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            mousePosition.z = 0f;
            lineRenderer.SetPosition(1,mousePosition);
            endOfPoin = mousePosition;
        }
        if (Input.GetMouseButtonUp(0))
        {
            isAction = false;
            RaycastHit2D raycastHit2D = Physics2D.Raycast(endOfPoin, Vector2.zero);
            if(raycastHit2D.collider != null && raycastHit2D.collider.TryGetComponent(out checkMatch) && objectIDKey == checkMatch.getID())
            {
                coutWin++;
                if(coutWin >= 4)
                {
                    print("Win");
                }
                print("correct Form");
            }else
            {
                lineRenderer.positionCount = 0;
            }
            lineRenderer.positionCount = 2;
        }

    }
}
